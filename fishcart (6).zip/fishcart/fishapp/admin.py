from django.contrib import admin
from.models import *

# Register your models here.
admin.site.register(addfishcategory)
admin.site.register(addfishdetatls)
admin.site.register(saveuser)
admin.site.register(Fwcart)
admin.site.register(checkoutdet)
admin.site.register(savecontactdata)